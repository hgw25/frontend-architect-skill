from pathlib import Path
assert Path('state.txt').read_text() == '1', 'state transition missing'
print('accepted actual state=1')
