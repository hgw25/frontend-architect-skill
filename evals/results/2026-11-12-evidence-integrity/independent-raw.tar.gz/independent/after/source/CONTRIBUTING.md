Use the supported checks.
