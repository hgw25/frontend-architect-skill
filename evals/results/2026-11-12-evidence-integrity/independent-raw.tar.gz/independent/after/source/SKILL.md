Read the fixture. Deliver only the requested state change.
